﻿namespace GCTTechnicalAssessment.Models
{
    public class Village
    {
        public int Id { get; set; }
        public string VillageName { get; set; } = string.Empty;
    }
}
