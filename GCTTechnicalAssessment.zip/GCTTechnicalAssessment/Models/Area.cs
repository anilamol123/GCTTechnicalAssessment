﻿namespace GCTTechnicalAssessment.Models
{
    public class Area
    {
        public int Id { get; set; }
        public string AreaName { get; set; } = string.Empty;
    }
}
