﻿
using System.ComponentModel.DataAnnotations;

namespace GCTTechnicalAssessment.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        [Required]
        public string TypeofEntity { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Phonenumber { get; set; }
        [Required]
        public string Region { get; set; } = string.Empty;
        [Required]
        public  Region Regions { get; set; }
        [Required]
        public string Wilaya { get; set; } = string.Empty;
        public Wilaya Wilayas { get; set; }
        [Required]
        public string Area { get; set; } = string.Empty;
        public Area Areas { get; set; }
        [Required]
        public string Village { get; set; }
        public Village Villages { get; set; }
        [Required]
        public string DetailsOfOpenDataExperience { get; set; }
        [Required]
        public string Remarks { get; set; }

    }
}
