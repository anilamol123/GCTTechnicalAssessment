﻿namespace GCTTechnicalAssessment.Models
{
    public class Wilaya
    {
        public int Id { get; set; }
        public string WilayaName { get; set; } = string.Empty;
    }
}
