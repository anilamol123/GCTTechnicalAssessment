﻿namespace GCTTechnicalAssessment.Models
{
    public class Region
    {
        public int id { get; set; }
        public string RegionName { get; set; }
    }
}
