using GCTTechnicalAssessment.DAL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GCTTechnicalAssessment.Models;

namespace GCTTechnicalAssessment.Pages.Users
{
    public class UserRegModel : PageModel
    {
        public readonly AppDbContext _context;
        public UserRegModel(AppDbContext context)
        {
            _context = context;
        }
        [BindProperty]
        public User User { get; set; }
        public List<Wilaya> Wilayas { get; set; } = new List<Wilaya>();
        public List<Area> Areas { get; set; } = new List<Area>();
        public List<Region> Regions { get; set; } = new List<Region>();
        public List<Village> Villages { get; set; } = new List<Village>();
        public ActionResult OnGet()
        {
            Wilayas = _context.Wilayas.ToList();
            Areas = _context.Areas.ToList();
            Regions = _context.Regions.ToList();
            Villages = _context.Villages.ToList();
            return Page();
        }
        public ActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                Wilayas = _context.Wilayas.ToList();
                Areas = _context.Areas.ToList();
                Regions = _context.Regions.ToList();
                Villages = _context.Villages.ToList();
                return Page();
            }
            _context.Users.Add(User);
            _context.SaveChanges();
            return RedirectToPage("/Users/UserReg");
        }
       
    }
}
